import express from "express";
import cors from "cors";
import session from "express-session";
import db from "./db.js";
import multer from "multer";
import fs from "fs";
import bcrypt from "bcrypt";
import https from "https";
const app = express();
if (!fs.existsSync("uploads")) {
  fs.mkdirSync("uploads");
}
// --------------------
// Middleware
// --------------------
app.use(cors());
app.use(express.static("public"));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use("/uploads", express.static("uploads"));
app.use(
  session({
    secret: process.env.SESSION_SECRET,
    resave: false,
    saveUninitialized: false,
  }),
);

// --------------------
// View Engine
// --------------------
app.set("view engine", "ejs");
app.set("views", "./views");

// --------------------
// Auth Middleware
// --------------------
function requireAdmin(req, res, next) {
  if (!req.session.isAdmin) {
    return res.redirect("/login");
  }
  next();
}

// --------------------
// Routes
// --------------------

// Home
app.get("/", (req, res) => {
  const status = "Online";
  const statusClass = status === "Online" ? "text-green-500" : "text-red-500";

  res.render("index", { status, statusClass });
});

// Safe page
app.get("/safe", (req, res) => {
  res.render("safe");
});
app.post("/safe", (req, res) => {
  const { name, location } = req.body;

  if (!name) {
    return res.status(400).send("Name required");
  }

  db.run(
    "INSERT INTO safe_people (name, location) VALUES (?, ?)",
    [name, location],
    function (err) {
      if (err) {
        console.error(err);
        return res.status(500).send("Database error");
      }

      res.json({ success: true, id: this.lastID });
    },
  );
});

// Report Page
app.get("/report", (req, res) => {
  res.render("report");
});

// Assist others page
app.get("/assist", (req, res) => {
  res.render("assist");
});

app.post("/assist", async (req, res) => {
  const { name, phone, password, skills, location } = req.body;

  if (!name || !phone || !password || !skills || !location) {
    return res.status(400).send("All fields are required");
  }

  try {
    const hashedPassword = await bcrypt.hash(password, 10);

    const query = `
      INSERT INTO volunteers 
      (name, phone, password, skills, location) 
      VALUES (?, ?, ?, ?, ?)
    `;

    db.run(
      query,
      [name, phone, hashedPassword, skills, location],
      function (err) {
        if (err) {
          console.error(err);
          return res.status(500).send("Database error");
        }

        res.json({
          success: true,
          message: "Volunteer application submitted successfully",
          id: this.lastID,
        });
      },
    );
  } catch (err) {
    console.error(err);
    res.status(500).send("Server error");
  }
});

// Volunteer Auth & Dashboard
app.get("/volunteer/login", (req, res) => {
  res.render("volunteer_login");
});

app.post("/volunteer/login", (req, res) => {
  const { phone, password } = req.body;

  if (!phone || !password) {
    return res.status(400).send("Phone and password required");
  }

  db.get(
    "SELECT * FROM volunteers WHERE phone = ?",
    [phone],
    async (err, volunteer) => {
      if (err) return res.status(500).send("Database error");
      if (!volunteer) return res.status(401).send("Invalid credentials");
      if (!volunteer.password)
        return res
          .status(401)
          .send("Account has no password set. Please re-register.");

      try {
        const match = await bcrypt.compare(password, volunteer.password);
        if (match) {
          req.session.volunteerId = volunteer.id;
          return res.redirect("/volunteer/dashboard");
        }
      } catch (compareErr) {
        console.error(compareErr);
      }

      res.status(401).send("Invalid credentials");
    },
  );
});

app.get("/volunteer/logout", (req, res) => {
  req.session.destroy(() => {
    res.redirect("/");
  });
});

app.get("/volunteer/dashboard", (req, res) => {
  if (!req.session.volunteerId) {
    return res.redirect("/volunteer/login");
  }

  db.get(
    "SELECT * FROM volunteers WHERE id = ?",
    [req.session.volunteerId],
    (err, volunteer) => {
      if (err || !volunteer)
        return res.status(500).send("Database error or user not found");

      if (volunteer.status === "pending") {
        res.render("volunteer_dashboard", {
          volunteer,
          requests: [],
          hazards: [],
        });
      } else {
        db.all(
          "SELECT * FROM requests WHERE status != 'resolved' ORDER BY urgency DESC",
          [],
          (err2, requests) => {
            if (err2) return res.status(500).send("Database error");

            db.all(
              "SELECT * FROM hazards WHERE status != 'resolved' ORDER BY created_at DESC",
              [],
              (err3, hazards) => {
                if (err3) return res.status(500).send("Database error");

                res.render("volunteer_dashboard", {
                  volunteer,
                  requests,
                  hazards,
                });
              },
            );
          },
        );
      }
    },
  );
});

// Request form page
app.get("/request", (req, res) => {
  res.render("request");
});
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "uploads/");
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + "-" + file.originalname);
  },
});

const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB
  fileFilter: (req, file, cb) => {
    if (file.mimetype.startsWith("image/")) {
      cb(null, true);
    } else {
      cb(new Error("Only images allowed"));
    }
  },
});
// Handle request submission
app.post("/request", upload.single("image"), (req, res) => {
  const { name, phone, type, location, urgency } = req.body;

  if (!name) {
    return res.status(400).send("Name required");
  }

  const imagePath = req.file ? req.file.filename : null;

  const query = `
    INSERT INTO requests 
    (name, phone, type, location, urgency, image) 
    VALUES (?, ?, ?, ?, ?, ?)
  `;

  db.run(
    query,
    [name, phone, type, location, urgency, imagePath],
    function (err) {
      if (err) {
        console.error(err);
        return res.status(500).send("Database error");
      }

      res.json({
        success: true,
        message: "Request submitted successfully",
        id: this.lastID,
      });
    },
  );
});

// Handle hazard report submission
app.post("/report", upload.single("image"), (req, res) => {
  const { description, location } = req.body;

  if (!description || !location) {
    return res.status(400).send("Description and location required");
  }

  const imagePath = req.file ? req.file.filename : null;

  const query = `
    INSERT INTO hazards 
    (description, location, image) 
    VALUES (?, ?, ?)
  `;

  db.run(query, [description, location, imagePath], function (err) {
    if (err) {
      console.error(err);
      return res.status(500).send("Database error");
    }

    res.json({
      success: true,
      message: "Hazard reported successfully",
      id: this.lastID,
    });
  });
});

// Login page
app.get("/login", (req, res) => {
  res.render("login");
});

app.post("/login", (req, res) => {
  const { username, password } = req.body;

  if (!username || !password) {
    return res.status(400).send("Username and password required");
  }

  if (
    username === process.env.ADMIN_USERNAME &&
    password === process.env.ADMIN_PASSWORD
  ) {
    req.session.isAdmin = true;
    return res.redirect("/admin");
  }

  res.status(401).send("Invalid credentials");
});

// Admin panel
app.get("/admin", requireAdmin, (req, res) => {
  if (!req.session.isAdmin) {
    return res.redirect("/login");
  }

  db.all(
    "SELECT * FROM requests ORDER BY created_at DESC",
    [],
    (err, requests) => {
      if (err) return res.status(500).send("Database error");

      db.get(
        "SELECT COUNT(*) as count FROM safe_people",
        [],
        (err2, safeCount) => {
          if (err2) return res.status(500).send("Database error");

          db.all(
            "SELECT * FROM hazards ORDER BY created_at DESC",
            [],
            (err3, hazards) => {
              if (err3) return res.status(500).send("Database error");

              db.all(
                "SELECT * FROM volunteers ORDER BY created_at DESC",
                [],
                (err4, volunteers) => {
                  if (err4) return res.status(500).send("Database error");

                  const criticalCount = requests.filter(
                    (r) =>
                      r.urgency === "critical" ||
                      (!r.urgency && r.type === "medical"),
                  ).length;
                  const highCount = requests.filter(
                    (r) =>
                      r.urgency === "high" ||
                      (!r.urgency && r.type !== "medical"),
                  ).length;

                  res.render("admin", {
                    requests,
                    hazards,
                    volunteers,
                    safeCount: safeCount.count,
                    criticalCount,
                    highCount,
                  });
                },
              );
            },
          );
        },
      );
    },
  );
});
// Logout
app.get("/logout", (req, res) => {
  req.session.destroy(() => {
    res.redirect("/login");
  });
});

app.post("/admin/request/:id/status", requireAdmin, (req, res) => {
  const { id } = req.params;
  const { status } = req.body;

  if (!["pending", "in_progress", "resolved"].includes(status)) {
    return res.status(400).send("Invalid status");
  }

  db.run(
    "UPDATE requests SET status = ? WHERE id = ?",
    [status, id],
    function (err) {
      if (err) {
        console.error(err);
        return res.status(500).send("Database error");
      }
      res.json({ success: true });
    },
  );
});

app.delete("/admin/request/:id", requireAdmin, (req, res) => {
  const { id } = req.params;

  db.run("DELETE FROM requests WHERE id = ?", [id], function (err) {
    if (err) {
      console.error(err);
      return res.status(500).send("Database error");
    }
    res.json({ success: true });
  });
});

app.post("/admin/hazard/:id/status", requireAdmin, (req, res) => {
  const { id } = req.params;
  const { status } = req.body;

  if (!["pending", "in_progress", "resolved"].includes(status)) {
    return res.status(400).send("Invalid status");
  }

  db.run(
    "UPDATE hazards SET status = ? WHERE id = ?",
    [status, id],
    function (err) {
      if (err) {
        console.error(err);
        return res.status(500).send("Database error");
      }
      res.json({ success: true });
    },
  );
});

app.delete("/admin/hazard/:id", requireAdmin, (req, res) => {
  const { id } = req.params;

  db.run("DELETE FROM hazards WHERE id = ?", [id], function (err) {
    if (err) {
      console.error(err);
      return res.status(500).send("Database error");
    }
    res.json({ success: true });
  });
});

app.post("/admin/volunteer/:id/status", requireAdmin, (req, res) => {
  const { id } = req.params;
  const { status } = req.body;

  if (!["pending", "approved"].includes(status)) {
    return res.status(400).send("Invalid status");
  }

  db.run(
    "UPDATE volunteers SET status = ? WHERE id = ?",
    [status, id],
    function (err) {
      if (err) {
        console.error(err);
        return res.status(500).send("Database error");
      }
      res.json({ success: true });
    },
  );
});

app.delete("/admin/volunteer/:id", requireAdmin, (req, res) => {
  const { id } = req.params;

  db.run("DELETE FROM volunteers WHERE id = ?", [id], function (err) {
    if (err) {
      console.error(err);
      return res.status(500).send("Database error");
    }
    res.json({ success: true });
  });
});

// Logout
app.get("/logout", (req, res) => {
  req.session.destroy(() => {
    res.redirect("/login");
  });
});

// --------------------
// Start Server
// --------------------
const port = 3000;

https
  .createServer(
    {
      key: fs.readFileSync("key.pem"),
      cert: fs.readFileSync("cert.pem"),
    },
    app,
  )
  .listen(3000, "0.0.0.0", () => {
    console.log("HTTPS running on port 3000");
  });
